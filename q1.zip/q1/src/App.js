import React, { useState } from 'react';
import './App.css';

function App() {
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState('');
  const [newPriority, setNewPriority] = useState('');

  const [editingIndex, setEditingIndex] = useState(-1);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editPriority, setEditPriority] = useState('');

  const handleAddItem = () => {
    setItems([...items, { name: newItem, priority: newPriority }]);
    setNewItem('');
    setNewPriority('');
  };

  const handleRemoveItem = (index) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    setItems(newItems);
  };

  const handlePriorityChange = () => {
    const newItems = [...items];
    newItems[editingIndex].priority = editPriority;
    setItems(newItems);
    setShowEditModal(false);
    setEditingIndex(-1);
  };

  const handleMoveToTop = (index) => {
    const newItems = [...items];
    const item = newItems.splice(index, 1)[0];
    newItems.unshift(item);
    setItems(newItems);
  };

  return (
    <div className="App">
      <h1>Wish List</h1>
      <form onSubmit={(e) => e.preventDefault()}>
        <label>
          Add item:
          <input type="text" value={newItem} onChange={(e) => setNewItem(e.target.value)} />
        </label>
        <label>
          Priority:
          <select value={newPriority} onChange={(e) => setNewPriority(e.target.value)}>
            <option value="">Select priority</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </label>
        <button onClick={handleAddItem} disabled={!newItem || !newPriority}>Add</button>
      </form>
      <ul>
        {items.map((item, index) => (
          <li key={index}>
            <span>{item.name}</span>
            <span>Priority: {item.priority}</span>
            <button onClick={() => handleRemoveItem(index)}>Remove</button>
            <button onClick={() => { setEditingIndex(index); setShowEditModal(true); }}>Edit priority</button>
            <button onClick={() => handleMoveToTop(index)}>Move to top</button>
          </li>
        ))}
      </ul>
      {showEditModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Edit Priority</h2>
            <select value={editPriority} onChange={(e) => setEditPriority(e.target.value)}>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
            <div className="modal-actions">
              <button onClick={() => setShowEditModal(false)}>Cancel</button>
              <button onClick={handlePriorityChange}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;