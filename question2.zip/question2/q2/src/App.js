import logo from './logo.svg';
import './App.css';
import React, { useState } from "react";
import axios from "axios";

function App() {

  const [searchTerm, setSearchTerm] = useState("");
  const [results, setResults] = useState([]);

  const handleSearch = async () => {
    if (searchTerm.trim() !== "") {
      try {
        const response = await axios.get(
          `https://api.github.com/search/users?q=${searchTerm}`
        );
        setResults(response.data.items);
      } catch (error) {
        console.error(error);
      }
    }
  };

  return (
    <div className="App">
      <div>
      <h1>Github User Search</h1>
      <input
        type="text"
        placeholder="Search Github Users"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>
      <ul>
      <div className='container'>
        {results.map((user) => (

         
          <li key={user.id}>

            <div className='name_plate'>
            <img className="img" src={user.avatar_url} alt={`${user.login} avatar`} />
            <a href={user.html_url} target="_blank" rel="noreferrer">
              {user.login}
            </a>
            </div>
          </li>
          
        ))}
        </div>
      </ul>
    </div>
    </div>
  );
}

export default App;